--
-- PostgreSQL database dump
--

\restrict XaZSAURa4OyIAYB9ZtYwuazEgMpRcirnUVAugT3hbhYzqix6Tdvq6Ynfw9o2jta

-- Dumped from database version 15.17 (Debian 15.17-1.pgdg13+1)
-- Dumped by pg_dump version 15.17 (Debian 15.17-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: scene_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scene_categories (
    id character varying(32) NOT NULL,
    name character varying(50) NOT NULL,
    icon character varying(20),
    cover_image character varying(500),
    description character varying(200),
    display_order integer DEFAULT 0,
    is_new boolean DEFAULT false,
    is_visible boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.scene_categories OWNER TO postgres;

--
-- Name: scene_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scene_items (
    id character varying(32) NOT NULL,
    scene_id character varying(32) NOT NULL,
    item_type character varying(20) DEFAULT 'chinese'::character varying,
    item_index integer,
    text character varying(50),
    text_pinyin character varying(100),
    text_english character varying(100),
    coordinates jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.scene_items OWNER TO postgres;

--
-- Name: scenes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.scenes (
    id character varying(32) NOT NULL,
    category_id character varying(32) NOT NULL,
    name character varying(50) NOT NULL,
    cover_image character varying(500),
    interactive_image character varying(500),
    description character varying(200),
    item_count integer DEFAULT 0,
    display_order integer DEFAULT 0,
    is_new boolean DEFAULT false,
    is_visible boolean DEFAULT true,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    items_data jsonb DEFAULT '[]'::jsonb,
    name_en character varying(100),
    context text
);


ALTER TABLE public.scenes OWNER TO postgres;

--
-- Name: user_learning_records; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_learning_records (
    id character varying(32) NOT NULL,
    user_id character varying(32) NOT NULL,
    scene_id character varying(32) NOT NULL,
    learned_items jsonb DEFAULT '[]'::jsonb,
    learned_item_count integer DEFAULT 0,
    total_study_time integer DEFAULT 0,
    last_study_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.user_learning_records OWNER TO postgres;

--
-- Name: user_daily_study_stats; Type: VIEW; Schema: public; Owner: postgres
--

CREATE VIEW public.user_daily_study_stats AS
 SELECT user_learning_records.user_id,
    date(user_learning_records.last_study_at) AS study_date,
    count(DISTINCT user_learning_records.scene_id) AS scenes_count,
    sum(user_learning_records.total_study_time) AS total_time
   FROM public.user_learning_records
  WHERE (user_learning_records.last_study_at IS NOT NULL)
  GROUP BY user_learning_records.user_id, (date(user_learning_records.last_study_at));


ALTER TABLE public.user_daily_study_stats OWNER TO postgres;

--
-- Name: user_favorites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.user_favorites (
    id character varying(32) NOT NULL,
    user_id character varying(32) NOT NULL,
    scene_id character varying(32) NOT NULL,
    favorited_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.user_favorites OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id character varying(32) NOT NULL,
    phone character varying(20) NOT NULL,
    password_hash character varying(255) NOT NULL,
    nickname character varying(50) NOT NULL,
    avatar character varying(500),
    role_type integer DEFAULT 1,
    is_vip boolean DEFAULT false,
    vip_expire_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    last_login_at timestamp without time zone,
    login_fail_count integer DEFAULT 0,
    locked_until timestamp without time zone,
    is_deleted boolean DEFAULT false,
    role_id integer DEFAULT 1 NOT NULL,
    CONSTRAINT chk_users_role_id CHECK ((role_id = ANY (ARRAY[1, 2])))
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Data for Name: scene_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scene_categories (id, name, icon, cover_image, description, display_order, is_new, is_visible, created_at, updated_at) FROM stdin;
cat_002	数学思维	数学	http://img.mtrain.xyz/kiki/categories/3812ac44-9dc3-4c3f-af1f-c4a57dbb4ea8.png	简单数字	2	f	t	2026-01-27 17:41:53.003695	2026-03-20 06:57:16.544467
cat_003	日常生活	🏠	http://img.mtrain.xyz/kiki/categories/1d884099-80c6-49f6-b930-6fc0bf6b5342.jpg	贴近生活的日常场景	3	f	t	2026-01-27 17:41:53.003695	2026-03-20 07:40:56.231431
cat_004	游乐场景	🎢	http://img.mtrain.xyz/kiki/categories/da3d19f5-1c49-4c99-9583-e39d7f6589cd.png	探索有趣的游乐世界，在丰富多彩的游乐场景中自由探索与成长。	4	f	t	2026-01-27 17:41:53.003695	2026-03-21 08:51:01.385441
cat_fdb7d74766a8	晨光乐趣	晨光	http://img.mtrain.xyz/kiki/categories/b72a5818-8593-4453-8a11-dc560dffb5ae.png	在校园晨间时光充满欢笑	0	f	t	2026-03-18 16:07:36.057786	2026-03-21 08:54:43.876963
\.


--
-- Data for Name: scene_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scene_items (id, scene_id, item_type, item_index, text, text_pinyin, text_english, coordinates, created_at) FROM stdin;
\.


--
-- Data for Name: scenes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.scenes (id, category_id, name, cover_image, interactive_image, description, item_count, display_order, is_new, is_visible, created_at, updated_at, items_data, name_en, context) FROM stdin;
scene_a255382dc2c7	cat_fdb7d74766a8	宝宝的玩具	http://img.mtrain.xyz/kiki/scenes/b09f5841-d67d-4d4f-bf56-28f8c6b7fbed.png	http://img.mtrain.xyz/kiki/scenes/22c60e1a-fbba-44ee-b00e-92d203e0eb3b.png	游乐园孩子的玩具	6	1	f	t	2026-03-20 15:31:31.850428	2026-03-24 15:17:15.951155	[{"id": "label_chinese_03", "text": "球", "type": "chinese", "index": 3, "coordinate": [{"x": 70, "y": 430}, {"x": 421, "y": 430}, {"x": 70, "y": 589}, {"x": 421, "y": 589}], "text_pinyin": "qiú", "text_english": "Ball"}, {"id": "label_chinese_04", "text": "鸭子", "type": "chinese", "index": 4, "coordinate": [{"x": 471, "y": 351}, {"x": 834, "y": 351}, {"x": 471, "y": 523}, {"x": 834, "y": 523}], "text_pinyin": "yā zi", "text_english": "Duck"}, {"id": "label_chinese_05", "text": "积木", "type": "chinese", "index": 5, "coordinate": [{"x": 622, "y": 516}, {"x": 987, "y": 516}, {"x": 622, "y": 640}, {"x": 987, "y": 640}], "text_pinyin": "jī mù", "text_english": "Blocks"}, {"id": "label_chinese_06", "text": "汽车", "type": "chinese", "index": 6, "coordinate": [{"x": 559, "y": 671}, {"x": 949, "y": 671}, {"x": 559, "y": 912}, {"x": 949, "y": 912}], "text_pinyin": "qì chē", "text_english": "Car"}, {"id": "label_chinese_07", "text": "拨浪鼓", "type": "chinese", "index": 7, "coordinate": [{"x": 354, "y": 689}, {"x": 509, "y": 689}, {"x": 354, "y": 942}, {"x": 509, "y": 942}], "text_pinyin": "bō lang gǔ", "text_english": "Drum"}, {"id": "label_chinese_08", "text": "摇铃", "type": "chinese", "index": 8, "coordinate": [{"x": 57, "y": 606}, {"x": 362, "y": 606}, {"x": 57, "y": 818}, {"x": 362, "y": 818}], "text_pinyin": "yáo líng", "text_english": "Rattle"}]	spring	
scene_101	cat_003	上学	http://img.mtrain.xyz/kiki/scenes/18d53ab6-e119-4857-8786-6845d23b31ba.png	http://img.mtrain.xyz/kiki/scenes/77341357-0eb1-491b-b21c-fe194028cbdd.png	2222	14	1	f	t	2026-01-27 17:41:53.004643	2026-03-18 15:53:15.640189	[{"id": "chinese_pinyin_01", "text": "动物世界", "type": "chinese", "index": 1, "coordinate": [{"x": 198, "y": 197}, {"x": 378, "y": 197}, {"x": 378, "y": 295}, {"x": 198, "y": 295}], "text_pinyin": "dòng wù shì jiè", "text_english": "Animal World"}, {"id": "chinese_pinyin_02", "text": "双语认知大发现", "type": "chinese", "index": 2, "coordinate": [{"x": 377, "y": 478}, {"x": 1031, "y": 478}, {"x": 1031, "y": 591}, {"x": 377, "y": 591}], "text_pinyin": "shuāng yǔ rèn zhī dà fā xiàn", "text_english": "Bilingual Cognitive Discovery"}, {"id": "chinese_pinyin_03", "text": "猴子", "type": "chinese", "index": 3, "coordinate": [{"x": 478, "y": 623}, {"x": 537, "y": 623}, {"x": 537, "y": 715}, {"x": 478, "y": 715}], "text_pinyin": "hóu zi", "text_english": "Monkey"}, {"id": "chinese_pinyin_04", "text": "狮子", "type": "chinese", "index": 4, "coordinate": [{"x": 549, "y": 830}, {"x": 595, "y": 830}, {"x": 595, "y": 922}, {"x": 549, "y": 922}], "text_pinyin": "shī zi", "text_english": "Lion"}, {"id": "chinese_pinyin_05", "text": "大象", "type": "chinese", "index": 5, "coordinate": [{"x": 792, "y": 1075}, {"x": 836, "y": 1075}, {"x": 836, "y": 1162}, {"x": 792, "y": 1162}], "text_pinyin": "dà xiàng", "text_english": "Elephant"}, {"id": "chinese_pinyin_06", "text": "斑马", "type": "chinese", "index": 6, "coordinate": [{"x": 952, "y": 883}, {"x": 992, "y": 883}, {"x": 992, "y": 973}, {"x": 952, "y": 973}], "text_pinyin": "bān mǎ", "text_english": "Zebra"}, {"id": "chinese_pinyin_07", "text": "长颈鹿", "type": "chinese", "index": 7, "coordinate": [{"x": 1037, "y": 707}, {"x": 1087, "y": 707}, {"x": 1087, "y": 797}, {"x": 1037, "y": 797}], "text_pinyin": "cháng jǐng lù", "text_english": "Giraffe"}, {"id": "chinese_pinyin_08", "text": "熊猫", "type": "chinese", "index": 8, "coordinate": [{"x": 1236, "y": 1367}, {"x": 1282, "y": 1367}, {"x": 1282, "y": 1459}, {"x": 1236, "y": 1459}], "text_pinyin": "xióng māo", "text_english": "Panda"}, {"id": "chinese_pinyin_09", "text": "鹦鹉", "type": "chinese", "index": 9, "coordinate": [{"x": 409, "y": 1638}, {"x": 449, "y": 1638}, {"x": 449, "y": 1735}, {"x": 409, "y": 1735}], "text_pinyin": "yīng wǔ", "text_english": "Parrot"}, {"id": "chinese_pinyin_10", "text": "河马", "type": "chinese", "index": 10, "coordinate": [{"x": 708, "y": 1740}, {"x": 752, "y": 1740}, {"x": 752, "y": 1833}, {"x": 708, "y": 1833}], "text_pinyin": "hé mǎ", "text_english": "Hippo"}, {"id": "chinese_pinyin_11", "text": "老虎", "type": "chinese", "index": 11, "coordinate": [{"x": 1338, "y": 1843}, {"x": 1381, "y": 1843}, {"x": 1381, "y": 1934}, {"x": 1338, "y": 1934}], "text_pinyin": "lǎo hǔ", "text_english": "Tiger"}, {"id": "chinese_pinyin_12", "text": "蛇", "type": "chinese", "index": 12, "coordinate": [{"x": 319, "y": 2152}, {"x": 363, "y": 2152}, {"x": 363, "y": 2246}, {"x": 319, "y": 2246}], "text_pinyin": "shé", "text_english": "Snake"}, {"id": "chinese_pinyin_13", "text": "乌龟", "type": "chinese", "index": 13, "coordinate": [{"x": 681, "y": 2055}, {"x": 727, "y": 2055}, {"x": 727, "y": 2147}, {"x": 681, "y": 2147}], "text_pinyin": "wū guī", "text_english": "Turtle"}, {"id": "chinese_pinyin_14", "text": "越野车", "type": "chinese", "index": 14, "coordinate": [{"x": 1208, "y": 1980}, {"x": 1253, "y": 1980}, {"x": 1253, "y": 2073}, {"x": 1208, "y": 2073}], "text_pinyin": "yuè yě chē", "text_english": "Safari Jeep"}]	211	12312312
\.


--
-- Data for Name: user_favorites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_favorites (id, user_id, scene_id, favorited_at) FROM stdin;
ufv_test_002	usr_test_001	scene_101	2026-01-15 14:00:00
\.


--
-- Data for Name: user_learning_records; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.user_learning_records (id, user_id, scene_id, learned_items, learned_item_count, total_study_time, last_study_at, created_at, updated_at) FROM stdin;
ulr_test_002	usr_test_001	scene_101	["item_101", "item_102"]	2	300	2026-01-17 14:00:00	2026-01-27 17:41:53.005477	2026-01-27 17:41:53.005477
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, phone, password_hash, nickname, avatar, role_type, is_vip, vip_expire_at, created_at, last_login_at, login_fail_count, locked_until, is_deleted, role_id) FROM stdin;
usr_test_002	13900139000	test123	测试用户2	\N	2	f	\N	2026-01-27 17:41:53.005198	2026-03-11 07:30:32.516389	0	\N	f	1
usr_test_001	13800138000	$2b$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lhWy	VIP测试用户	\N	1	t	\N	2026-01-27 17:41:53.005198	\N	0	\N	f	1
test_user_003	13800138003	password123	Test Update	\N	1	t	\N	2026-01-29 15:37:29.246667	2026-03-20 06:50:26.106269	0	\N	f	1
admin_002	13900139002	admin123	Admin User	\N	2	f	\N	2026-01-30 03:02:05.060596	2026-03-24 15:58:40.476411	0	\N	f	1
\.


--
-- Name: scene_categories scene_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scene_categories
    ADD CONSTRAINT scene_categories_pkey PRIMARY KEY (id);


--
-- Name: scene_items scene_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scene_items
    ADD CONSTRAINT scene_items_pkey PRIMARY KEY (id);


--
-- Name: scenes scenes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenes
    ADD CONSTRAINT scenes_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_pkey PRIMARY KEY (id);


--
-- Name: user_favorites user_favorites_user_id_scene_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_scene_id_key UNIQUE (user_id, scene_id);


--
-- Name: user_learning_records user_learning_records_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_records
    ADD CONSTRAINT user_learning_records_pkey PRIMARY KEY (id);


--
-- Name: user_learning_records user_learning_records_user_id_scene_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_records
    ADD CONSTRAINT user_learning_records_user_id_scene_id_key UNIQUE (user_id, scene_id);


--
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_categories_display_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_categories_display_order ON public.scene_categories USING btree (display_order);


--
-- Name: idx_categories_visible; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_categories_visible ON public.scene_categories USING btree (is_visible);


--
-- Name: idx_favorites_created; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_created ON public.user_favorites USING btree (favorited_at);


--
-- Name: idx_favorites_scene_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_scene_id ON public.user_favorites USING btree (scene_id);


--
-- Name: idx_favorites_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_favorites_user_id ON public.user_favorites USING btree (user_id);


--
-- Name: idx_items_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_index ON public.scene_items USING btree (item_index);


--
-- Name: idx_items_scene_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_items_scene_id ON public.scene_items USING btree (scene_id);


--
-- Name: idx_learning_last_study; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_learning_last_study ON public.user_learning_records USING btree (last_study_at);


--
-- Name: idx_learning_scene_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_learning_scene_id ON public.user_learning_records USING btree (scene_id);


--
-- Name: idx_learning_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_learning_user_id ON public.user_learning_records USING btree (user_id);


--
-- Name: idx_scenes_category_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scenes_category_id ON public.scenes USING btree (category_id);


--
-- Name: idx_scenes_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scenes_created_at ON public.scenes USING btree (created_at);


--
-- Name: idx_scenes_display_order; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scenes_display_order ON public.scenes USING btree (display_order);


--
-- Name: idx_scenes_visible; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_scenes_visible ON public.scenes USING btree (is_visible);


--
-- Name: idx_users_created_at; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_created_at ON public.users USING btree (created_at);


--
-- Name: idx_users_is_vip; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_is_vip ON public.users USING btree (is_vip);


--
-- Name: idx_users_phone; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_phone ON public.users USING btree (phone);


--
-- Name: idx_users_role_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role_id ON public.users USING btree (role_id);


--
-- Name: idx_users_role_type; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_users_role_type ON public.users USING btree (role_type);


--
-- Name: scene_items scene_items_scene_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scene_items
    ADD CONSTRAINT scene_items_scene_id_fkey FOREIGN KEY (scene_id) REFERENCES public.scenes(id) ON DELETE CASCADE;


--
-- Name: scenes scenes_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.scenes
    ADD CONSTRAINT scenes_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.scene_categories(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_scene_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_scene_id_fkey FOREIGN KEY (scene_id) REFERENCES public.scenes(id) ON DELETE CASCADE;


--
-- Name: user_favorites user_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_favorites
    ADD CONSTRAINT user_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_learning_records user_learning_records_scene_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_records
    ADD CONSTRAINT user_learning_records_scene_id_fkey FOREIGN KEY (scene_id) REFERENCES public.scenes(id) ON DELETE CASCADE;


--
-- Name: user_learning_records user_learning_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.user_learning_records
    ADD CONSTRAINT user_learning_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict XaZSAURa4OyIAYB9ZtYwuazEgMpRcirnUVAugT3hbhYzqix6Tdvq6Ynfw9o2jta

